package com.example.endterm;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SharedPrefDemo extends AppCompatActivity {
    EditText editTextMovie, editTextNOTickets;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_shared_pref_demo);
        editTextMovie = findViewById(R.id.editTextTextMovieName);
        editTextNOTickets = findViewById(R.id.editTextTextNOfTickets);
        button = findViewById(R.id.bookButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name  = editTextMovie.getText().toString();
                String no = editTextNOTickets.getText().toString();
                SharedPreferences sharedPreferences = getSharedPreferences("myPref",MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("Movie",name);
                editor.putString("number",no);
                editor.apply();
                Toast.makeText(SharedPrefDemo.this, "Booked", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = getSharedPreferences("myPref",MODE_PRIVATE);
        String n = sharedPreferences.getString("Movie","");
        String t = sharedPreferences.getString("number","");
        editTextMovie.setText(n);
        editTextNOTickets.setText(t);
    }
}