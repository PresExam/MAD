package com.example.endterm;

import static android.app.ProgressDialog.show;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    AutoCompleteTextView autoCompleteTextView;
    RadioGroup rg;
    RadioButton male, female;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        // using autocomplete and radio button
        String[] ar = {"sohit", "sohal","ajay"};
        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line,ar);
        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
        autoCompleteTextView.setAdapter(ad);
        rg = findViewById(R.id.radiogroup);
        male = findViewById(R.id.male);
        female = findViewById(R.id.female);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int checkedId = rg.getCheckedRadioButtonId();
                if(checkedId!=-1){
                    RadioButton selectedId = findViewById(checkedId);
                    String text = selectedId.getText().toString();
                    Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, NotficaPracDemo.class);
                    startActivity(intent);

                }else {
                    Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();

                }

            }
        });




    }

}