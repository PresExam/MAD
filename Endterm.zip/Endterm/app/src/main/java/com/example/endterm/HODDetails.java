package com.example.endterm;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;

public class HODDetails extends AppCompatActivity {
    DBHandlePrac dbHandlePrac;
    TextView textView;
    EditText editText;
    Button type, college, date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Using WindowCompat for edge-to-edge experience
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_hoddetails);

        date = findViewById(R.id.buttonDate);
        type = findViewById(R.id.buttonType);
        college = findViewById(R.id.buttonCollege);
        textView = findViewById(R.id.textViewFinal);
        editText = findViewById(R.id.editTextTextSearchValue);

        // Reinitialize the database object
        dbHandlePrac = new DBHandlePrac(getApplicationContext(), "invincia", null, 1);

        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String anss = dbHandlePrac.displayTicketType();
                textView.setText(anss);
            }
        });

        college.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String clgName = editText.getText().toString();
                String anss = dbHandlePrac.displayCollege(clgName);
                textView.setText(anss);
            }
        });

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String datee = editText.getText().toString();
                String anss = dbHandlePrac.displayDate(datee);
                textView.setText(anss);
            }
        });
    }
}
