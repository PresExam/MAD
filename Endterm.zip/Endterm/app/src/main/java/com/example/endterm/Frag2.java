package com.example.endterm;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

public class Frag2 extends Fragment {
    TextView result;
    String selected;
    String price;
    public Frag2(){}
    public Frag2(String item, String price) {
        this.selected=item;
        this.price=price;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_frag2,container,false);
        result = view.findViewById(R.id.textViewSelected);
        result.setText(selected+"\n"+price);
        return view;
    }



}