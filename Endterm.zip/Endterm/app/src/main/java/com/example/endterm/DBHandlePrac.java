package com.example.endterm;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.io.Serializable;

public class DBHandlePrac extends SQLiteOpenHelper implements Serializable {
    public DBHandlePrac(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table invincia(name varchar(20), roll varchar(20), college varchar(20), type varchar(20), date varchar(20))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insert(String name, String roll, String college, String type, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("insert into invincia values(?,?,?,?,?)", new String[]{name, roll, college, type, date});
        db.close();
    }

    public String displayDate(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from invincia where date=?", new String[]{date});
        String data = "";

        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String roll = cursor.getString(1);
            String college = cursor.getString(2);
            String type = cursor.getString(3);
            String dat = cursor.getString(4);
            data += name + " " + roll + " " + college + " " + type + " " + dat + "\n\n";
        }
        return data;
    }

    public String displayTicketType() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from invincia where type=?",new String[]{"Platinum"});
        String data = "";

        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String roll = cursor.getString(1);
            String college = cursor.getString(2);
            String type = cursor.getString(3);
            String dat = cursor.getString(4);
            data += name + " " + roll + " " + college + " " + type + " " + dat + "\n\n";
        }
        return data;
    }

    public String displayCollege(String collegeName) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from invincia where college=?", new String[]{collegeName});
        String data = "";

        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String roll = cursor.getString(1);
            String college = cursor.getString(2);
            String type = cursor.getString(3);
            String dat = cursor.getString(4);
            data += name + " " + roll + " " + college + " " + type + " " + dat + "\n\n";
        }
        return data;
    }
}
