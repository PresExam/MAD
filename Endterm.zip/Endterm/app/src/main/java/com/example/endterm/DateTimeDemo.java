package com.example.endterm;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class DateTimeDemo extends AppCompatActivity {
    EditText d, t;
    Calendar calendar;
    int month,day,year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_time_demo);
        calendar =  Calendar.getInstance();
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        year = calendar.get(Calendar.YEAR);
        d = findViewById(R.id.editTextDate);

        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(DateTimeDemo.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int ye, int mo, int dayOf) {
                        Toast.makeText(DateTimeDemo.this, String.format("%02d/%02d/%04d", dayOf, mo + 1, ye), Toast.LENGTH_SHORT).show();
                    }
                }, year, month, day); // June is month 5 (0-based index)
                datePickerDialog.show();
            }
        });
        t = findViewById(R.id.editTextTime);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(DateTimeDemo.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        t.setText(i+":"+i1);
                        Toast.makeText(DateTimeDemo.this, i+":"+i1, Toast.LENGTH_SHORT).show();
                    }
                },10,30,true);
                timePickerDialog.show();
            }
        });
    }
}
