package com.example.endterm;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DatabaseDemo extends AppCompatActivity {
    EditText id, name;
    Button insert , display;

    TextView result;
    DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_database_demo);
        dbHandler = new DBHandler(getApplicationContext(),"student",null,1);
        id= findViewById(R.id.editTextId);
        name = findViewById(R.id.editTextName);
        insert=  findViewById(R.id.insert);
        display = findViewById(R.id.display);
        result= findViewById(R.id.result);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String idd = id.getText().toString();
                String namee = name.getText().toString();
                dbHandler.insert(idd,namee);
                Toast.makeText(DatabaseDemo.this, "inserted", Toast.LENGTH_SHORT).show();
            }
        });

        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String results  = dbHandler.display();
                result.setText(results);
            }
        });



    }
}