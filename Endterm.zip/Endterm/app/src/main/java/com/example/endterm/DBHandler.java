package com.example.endterm;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHandler extends SQLiteOpenHelper {
    public DBHandler(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table student(id varchar(20),name varchar(20))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insert(String i , String name){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("insert into student values (?,?)",new String[]{i,name});
        db.close();
    }

    public String display(){
        String data = "";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from student",null);
        while (cursor.moveToNext()){
            String one=cursor.getString(0);
            String two = cursor.getString(1);

            data+=one+":"+two+"\n";
        }
        db.close();
        return data;
    }
}
