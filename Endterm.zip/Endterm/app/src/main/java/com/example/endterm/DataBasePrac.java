package com.example.endterm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DataBasePrac extends AppCompatActivity {
    DBHandlePrac db;
    EditText name, roll, college;
    Button button;
    RadioGroup rg1, rg2;
    RadioButton silver, gold, plat, date24, date25;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data_base_prac);
        name = findViewById(R.id.editTextTextName);
        roll = findViewById(R.id.editTextTextRoll);
        college = findViewById(R.id.editTextTextCollege);
        rg1 = findViewById(R.id.radiogroupType);
        rg2 = findViewById(R.id.radiogroupDate);
        silver = findViewById(R.id.radioButtonSilver);
        gold = findViewById(R.id.radioButtonGold);
        plat = findViewById(R.id.radioButtonPlatinum);
        date24 = findViewById(R.id.radioButton24);
        date25= findViewById(R.id.radioButton25);
        button = findViewById(R.id.submit);
        db = new DBHandlePrac(getApplicationContext(),"invincia",null,1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int checkedId1= rg1.getCheckedRadioButtonId();
                int checkedId2= rg2.getCheckedRadioButtonId();
                RadioButton r1Selected = findViewById(checkedId1);
                RadioButton r2Selected = findViewById(checkedId2);
                String r1Val = r1Selected.getText().toString();
                String r2val = r2Selected.getText().toString();
                String nameval = name.getText().toString();
                String rollval = name.getText().toString();
                String collegeval = name.getText().toString();
                db.insert(nameval,rollval,collegeval,r1Val,r2val);
                Toast.makeText(DataBasePrac.this, "submitted", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(DataBasePrac.this, HODDetails.class);
                intent.putExtra("obj",db);
                startActivity(intent);
            }
        });
    }
}